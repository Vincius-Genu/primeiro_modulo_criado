# package_name

Description. 
The package relaxing_games is used to:
	checking_sudoku:
	- Check your sudoko game
	- Used to for 3 x 3 matriz
	games_3_in_one:
	- Play even or odd with a machine
	- Play rock, paper or scissors
	- Play blackjack
	
## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install relaxing_games

```bash
pip install relaxing_games
```

## Usage

```python
from relaxing_games import checking_sudoku
checking_sudoku.my_function()
from relaxing_games import games_3_in_one
checking_sudoku.my_function()
```

## Author
My_name

## License
[MIT](https://choosealicense.com/licenses/mit/)